export interface ObjectRes {
  res: Object;
  status: number;
}
export interface StringRes {
  res: string;
  status: number;
}
