export type Encrypt = string;
export type TokenGenerator = string;

export type CheckPassword = boolean;
export type Compare = boolean;
export type EmailValidatencry = boolean;
